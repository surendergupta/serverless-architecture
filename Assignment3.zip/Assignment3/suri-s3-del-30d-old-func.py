import boto3
from datetime import datetime, timedelta, timezone

def lambda_handler(event, context):
    # Replace 'your-bucket-name' with the actual name of your S3 bucket
    bucket_name = 'surenderbukb3'
    
    # Initialize a boto3 S3 client
    s3_client = boto3.client('s3')
    
    # List objects in the specified bucket
    objects = s3_client.list_objects(Bucket=bucket_name)['Contents']
    
    # Calculate the date threshold for objects older than 30 days
    threshold_date = datetime.now(timezone.utc) - timedelta(days=30)
    
    # Delete objects older than 30 days
    deleted_objects = []
    for obj in objects:
        last_modified = obj['LastModified'].replace(tzinfo=timezone.utc)
        if last_modified < threshold_date:
            s3_client.delete_object(Bucket=bucket_name, Key=obj['Key'])
            deleted_objects.append(obj['Key'])
    
    # Print the names of deleted objects for logging purposes
    if deleted_objects:
        print(f"Deleted objects: {deleted_objects}")
    else:
        print("No objects deleted.")
        
    return {
        'statusCode': 200,
        'body': 'S3 Deleted 30days Old files successfully!'
    }
