import boto3

def lambda_handler(event, context):
    # Initialize a boto3 S3 client
    s3_client = boto3.client('s3', region_name = 'us-east-1')
    
    # List all S3 buckets
    s3_buckets = s3_client.list_buckets()['Buckets']
    
    # Detect buckets without server-side encryption
    unencrypted_buckets = []
    for bucket in s3_buckets:
        bucket_name = bucket['Name']
        #print(bucket_name)
        try:
            bucket_encryption = s3_client.get_bucket_encryption(Bucket=bucket_name)
            server_side_encryption = bucket_encryption.get('ServerSideEncryptionConfiguration', [])
            for rules in server_side_encryption['Rules']:
                #print(rules['BucketKeyEnabled'])
                if rules['BucketKeyEnabled'] == False:
                    unencrypted_buckets.append(bucket_name)
                #rule = rules['Rules']
                #print(rule)
                
            #if not server_side_encryption:
                #unencrypted_buckets.append(bucket_name)
        except s3_client.exceptions.ClientError as e:
            # Handle the exception if the bucket does not have server-side encryption configured
            if e.response['Error']['Code'] == 'ServerSideEncryptionConfigurationNotFoundError':
                unencrypted_buckets.append(bucket_name)
    
    # Print the names of unencrypted buckets for logging purposes
    if unencrypted_buckets:
        print(f"Unencrypted buckets: {unencrypted_buckets}")
    else:
        print("All buckets are encrypted.")
        
    return {
        'statusCode': 200,
        'body': 'S3 unencrypted buckets found successfully!'
    }
