import json
import boto3

def lambda_handler(event, context):
    # Initialize a boto3 EC2 client
    ec2 = boto3.client('ec2', region_name = 'eu-north-1')

    # Specify the tag keys for Auto-Stop and Auto-Start
    auto_stop_tag_key = 'Action'
    auto_start_tag_key = 'Action'
    auto_stop_tag_value = 'Auto-Stop'
    auto_start_tag_value = 'Auto-Start'

    # Describe instances with Auto-Stop and Auto-Start tags
    auto_stop_instances = ec2.describe_instances(Filters=[{'Name': f'tag:{auto_stop_tag_key}', 'Values': [auto_stop_tag_value]}])
    auto_start_instances = ec2.describe_instances(Filters=[{'Name': f'tag:{auto_start_tag_key}', 'Values': [auto_start_tag_value]}])
    
    # Stop Auto-Stop instances
    stopped_instance_ids = []
    for reservation in auto_stop_instances['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            ec2.stop_instances(InstanceIds=[instance_id])
            stopped_instance_ids.append(instance_id)

    # Start Auto-Start instances
    started_instance_ids = []
    for reservation in auto_start_instances['Reservations']:
        for instance in reservation['Instances']:
            instance_id = instance['InstanceId']
            ec2.start_instances(InstanceIds=[instance_id])
            started_instance_ids.append(instance_id)

    # Print affected instance IDs for logging purposes
    print("Stopped instances:", stopped_instance_ids)
    print("Started instances:", started_instance_ids)

    return {
        'statusCode': 200,
        'body': 'EC2 instances managed successfully!'
    }