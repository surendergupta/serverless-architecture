import boto3
from datetime import datetime, timedelta, timezone

def lambda_handler(event, context):
    # Replace 'your-volume-id' with the actual ID of your EBS volume
    volume_id = 'vol-094a7c2d7c44777d6'
    
    # Initialize a boto3 EC2 client
    ec2_client = boto3.client('ec2', region_name='us-east-1')
    
    # Create a snapshot for the specified EBS volume
    snapshot_response = ec2_client.create_snapshot(
        VolumeId=volume_id,
        Description=f"EBS Snapshot for volume {volume_id}"
    )
    
    snapshot_id = snapshot_response['SnapshotId']
    
    # List snapshots for the specified EBS volume
    snapshots = ec2_client.describe_snapshots(Filters=[{'Name': 'volume-id', 'Values': [volume_id]}])['Snapshots']
    
    # Calculate the date threshold for snapshots older than 30 days
    threshold_date = datetime.now(timezone.utc) - timedelta(days=30)
    
    # Delete snapshots older than 30 days
    deleted_snapshots = []
    for snapshot in snapshots:
        # Convert the snapshot start time to an aware datetime object
        snapshot_start_time = snapshot['StartTime'].replace(tzinfo=timezone.utc)
        
        if snapshot_start_time < threshold_date:
            ec2_client.delete_snapshot(SnapshotId=snapshot['SnapshotId'])
            deleted_snapshots.append(snapshot['SnapshotId'])
    
    # Print the IDs of the created and deleted snapshots for logging purposes
    print(f"Created snapshot: {snapshot_id}")
    if deleted_snapshots:
        print(f"Deleted snapshots: {deleted_snapshots}")
    else:
        print("No snapshots deleted.")
    return {
        'statusCode': 200,
        'body': 'EBS successully executed'
    }
